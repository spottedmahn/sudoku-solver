#ifndef H_OneCell
#define H_OneCell

struct oneCell{
       
       int row,
           col,
           value;       
};

#endif
